import numpy as np
from DES import DES_encrypt,DES_decrypt,int2bits

TEST_MODEL = False

def read_bits_text(infile):
    fin = open(infile, "rb")
    t = fin.read()
    bit_text = np.zeros(len(t) * 8, dtype=np.bool_)
    for i, each in enumerate(t):
        for j in range(8):
            bit_text[i * 8 + j] = each & 1
            each >>= 1
    return bit_text

def write_bits_text(bit_text,outfile):
    output = bytearray(bit_text.size//8)
    with open(outfile,'wb') as fout:
        for i in range(bit_text.size//8):
            for j in range(8):
                output[i]<<=1
                output[i]+=bit_text[i*8+7-j]
        fout.write(output)

def unit_test(input_file="test0.txt",key=0xffff1234ffff1234):
    # encrypt test
    raw_text = read_bits_text(input_file)
    encrypted_text = DES_encrypt(raw_text, key)
    input_file=input_file.split('.')[0] + "_en." + input_file.split('.')[1]
    write_bits_text(encrypted_text, input_file)
    # decrypt test
    encrypted_text = read_bits_text(input_file)
    decrypted_text = DES_decrypt(encrypted_text, key)
    input_file=input_file.split('.')[0] + "_de." + input_file.split('.')[1]
    write_bits_text(decrypted_text, input_file)

def lab_test(input_file="test0.txt",key=0xffff1234ffff1234):

    raw_text = read_bits_text(input_file)
    encrypted_text = DES_encrypt(raw_text, key)
    num1 = len([b for b in encrypted_text if b == 1])
    num0 = encrypted_text.size - num1
    print(input_file+"加密后的01的比重")
    print("1:",num1/encrypted_text.size)
    print("0:",num0/encrypted_text.size)

    raw_text [12]  ^=1
    encrypted_text2 = DES_encrypt(raw_text, key)
    cnt = 0
    for i in range(encrypted_text.size):
        if encrypted_text[i]!=encrypted_text2[i]:
            cnt += 1
    print(input_file+"中一位发生改变时，加密文件改变的位的比例")
    print(cnt/encrypted_text.size)
    print()

    return num1/encrypted_text.size,num0/encrypted_text.size,cnt/encrypted_text.size


if __name__ == "__main__":
    if TEST_MODEL:
        keys = [0x1111222233334444,0xffff22223333cccc,0xffff1234ffff1234,0x1123456789091234]
        text = ["DES.py","main.py","README.md"]
        n1_list , n0_list , p_list = [],[],[]
        for each_text in text:
            for each_key in keys:
                n1,n0,p = lab_test(each_text,each_key)
                n1_list.append(n1)
                n0_list.append(n0)
                p_list.append(p)
        print("1的平均比重",sum(n1_list)/12)
        print("0的平均比重",sum(n0_list)/12)
        print("明文改变1位时，密文平均改变率",sum(p_list)/12)

    else:
        while 1:
            encode = ""
            input_file = ""
            output_file = ""
            while encode!=0 and encode!=1 and encode!=-1:
                try:
                    encode = int(input("请选择加密(输入1）或解密(输入0)[输入-1退出]"))
                except:pass
            if encode == -1:
                break
            while 1:
                try:
                    input_file=input("请输入64位秘钥（用16位16进制表示）:")
                    key = int(input_file.upper(),16)
                    if len(input_file)==16:
                        keys = int2bits(key,64)
                        check = True
                        for i in range(8):
                            x = 0
                            for j in range(7):
                                x ^= keys[i*8+j]
                            if x != keys[i*8+7]:
                                check = False
                        if check:
                            break
                        else:
                            print("错误：秘钥没有通过奇偶检验")
                            continue
                    else:
                        print("错误：秘钥格式错误！")
                except:pass
            while 1:
                if encode:
                    input_text = "请输入需要加密的文件名:"
                    input_file = input(input_text)
                    try:
                        raw_text = read_bits_text(input_file)
                        encrypted_text = DES_encrypt(raw_text, key)
                        input_file = input_file.split('.')[0] + "_en." + input_file.split('.')[1]
                        write_bits_text(encrypted_text, input_file)
                        print("加密成功!")
                        break
                    except:
                        print("错误：文件打开失败!")
                else:
                    input_text = "请输入需要解密的文件名:"
                    input_file = input(input_text)
                    try:
                        encrypted_text = read_bits_text(input_file)
                        if encrypted_text.size % 64:
                            print("错误：待解码文件的长度不是64的倍数！")
                            continue
                        decrypted_text = DES_decrypt(encrypted_text,key)
                        input_file = input_file.split('.')[0] + "_de." + input_file.split('.')[1]
                        write_bits_text(decrypted_text, input_file)
                        print("解密成功！")
                        break
                    except:
                        print("错误：文件打开失败!")
